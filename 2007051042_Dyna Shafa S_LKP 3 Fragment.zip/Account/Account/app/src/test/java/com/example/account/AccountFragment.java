package com.example.account;

import androidx.fragment.app.Fragment;

public class AccountFragment extends Fragment {

}
