package com.example.account;

public interface CallBackFragment {
    void changeFragment();
}
